/**
 * For staging
 */
export const environment = {
    production: true,
    api_url: 'http://stagingbackendurl.com',
};
