/**
 * For production
 */
export const environment = {
  production: true,
  api_url: 'http://productionbackendapiurl.com',
};
